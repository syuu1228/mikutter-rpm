# -*- coding: utf-8 -*-

module CHIConfig
  LOGDIR = "~/.chi/log/"
  TWITTER_CONSUMER_KEY = "AmDS1hCCXWstbss5624kVw"
  TWITTER_CONSUMER_SECRET = "KOPOooopg9Scu7gJUBHBWjwkXz9xgPJxnhnhO55VQ"
  TWITTER_AUTHENTICATE_REVISION = 1
  NeverRetrieveOverlappedMumble = false
  TMPDIR = "~/.chi/tmp/"
  AutoTag = false
  CONFROOT = "~/.chi/"
  ACRO = "chi"
  CACHE = "~/.chi/cache/"
  PIDFILE = "/tmp/chi.pid"
  VERSION = [0, 0, 4, 456]
  NAME = "chi"
  REVISION = 456
end
