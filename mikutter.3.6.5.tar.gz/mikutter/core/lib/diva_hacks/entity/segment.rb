# -*- coding: utf-8 -*-

# module Retriever::Entity
#   Segment = Struct.new(:slug, :range, :face, :url, :open, :options) do
#     def merge(args)
#       new = self.dup
#       args.each do |k, v|
#         new[k] = v
#       end
#       new
#     end
#   end
# end
