# -*- coding: utf-8 -*-

class MikuTwitter
  VERSION = [1, 1]
end
