# -*- coding: utf-8 -*-

MIKUTWITTER_TEST_DIR = File.expand_path(File.dirname(__FILE__))
$LOAD_PATH.push(File.expand_path(File.join(File.dirname(__FILE__), '../../..')))
