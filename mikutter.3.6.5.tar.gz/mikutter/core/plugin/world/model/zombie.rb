# -*- coding: utf-8 -*-

module Plugin::World
  # 滅びた世界
  class Zombie < Diva::Model
    field.string :slug, required: true
  end
end
