# -*- coding: utf-8 -*-
module ::Plugin::Streaming
  class StreamerError; end end
